package Aula3007;

public class Estoque {

}
